

export const STUDENTLIST='https://localhost:44323/api/Student/List';
export const TEACHERSLIST='https://localhost:44323/api/Teacher/List';
export const ATTENDANCELIST='https://localhost:44323/api/Attendance/AttendanceReportsList';