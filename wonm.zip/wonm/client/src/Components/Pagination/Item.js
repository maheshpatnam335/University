export const columns = [
  {
    Header: "First Name",
    accessor: "academicYear"
  },
  {
    Header: "Last Name",
    accessor: "rollNumber"
  },
  {
    Header: "Age",
    accessor: "applicationNumber"
  },
  {
    Header: "Status",
    accessor: "status"
  },
  {
    Header: "Visits",
    accessor: "pendingAt"
  }
]
