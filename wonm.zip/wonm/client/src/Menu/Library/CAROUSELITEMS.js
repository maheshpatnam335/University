export const items = [
    {
        id: 1,
        src:'https://media.istockphoto.com/id/1401178943/photo/young-lady-using-a-laptop-to-do-research-on-the-internet-woman-working-on-a-project-mixed.jpg?b=1&s=170667a&w=0&k=20&c=aGfh1r7rvrxPz35szx1EAqEslOc2Q4c5hD5WN014jBQ=',
        altText: 'Slide 1',
        caption: 'Slide 1'
    },
    {
        id: 2,
        src: 'https://media.istockphoto.com/id/1334910903/photo/african-american-female-student-stands-in-university-library-looking-for-a-book-a-pretty.jpg?b=1&s=170667a&w=0&k=20&c=EQipMIhzVS41BmfEw5pA7pmZ6k6WLhI88BpRUSy2ghE=',
        altText: 'Slide 2',
        caption: 'Slide 2'
    },
    {
        id: 3,
        src: 'https://media.istockphoto.com/id/1401178950/photo/african-man-sitting-inside-a-library-alone-doing-research-man-working-on-a-project-young-man.jpg?b=1&s=170667a&w=0&k=20&c=1-7vJiknrH600McHpGYj5a9XKIShRRTT-5k-gNi1FpA=',
        altText: 'Slide 3',
        caption: 'Slide 3'
    },
    {
        id:4,
        src:'https://media.istockphoto.com/id/1408658175/photo/girl-taking-a-book-from-bookshelf-in-library.jpg?b=1&s=170667a&w=0&k=20&c=72sWCtJPiZj9ri2VwguEjGQ1G9Q_DUngM4Rh_lO8E9Q=',
        altText:'Slide 4',
        caption:'Slide 4'
    },
    {
        id:'5',
        src:'https://images.unsplash.com/photo-1568667256549-094345857637?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8NXx8bGlicmFyeXxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60',
        altText:'Slide 5',
        caption:'Slide 5'
    },
    {
        id:6,
        src:'https://images.unsplash.com/photo-1614849963640-9cc74b2a826f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTF8fGxpYnJhcnl8ZW58MHx8MHx8&auto=format&fit=crop&w=500&q=60',
        altText:'Slide 6',
        caption:'Slide 6'
    }
];