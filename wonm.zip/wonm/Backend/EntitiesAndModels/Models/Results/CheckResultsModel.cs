﻿namespace EntitiesAndModels.Models.Results
{
    public class CheckResultsModel
    {
        public string RollNumber { get; set; }
        public string Dob { get; set; }
        public int Semester { get; set; }
        public int Class { get; set; }
    }
}
