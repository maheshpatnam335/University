﻿////using Microsoft.EntityFrameworkCore;

////namespace BusinessLogic
////{
////    public interface IBaseService<T>
////    {
////        void Add(T Entity);
////    }
////    public class BaseService<T> : IBaseService
////    {
////        protected DbContext dbContext;

////        public void Add(T Entity)
////        {
////            dbContext.Add(Entity);
////        }
////    }
////}
