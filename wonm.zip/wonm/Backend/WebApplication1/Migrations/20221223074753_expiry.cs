﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace WebApi.Migrations
{
    /// <inheritdoc />
    public partial class expiry : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Students_Subjects_Student_Results_ResultsId",
                table: "Students_Subjects");

            migrationBuilder.RenameColumn(
                name: "ResultsId",
                table: "Students_Subjects",
                newName: "StudentResultsId");

            migrationBuilder.RenameIndex(
                name: "IX_Students_Subjects_ResultsId",
                table: "Students_Subjects",
                newName: "IX_Students_Subjects_StudentResultsId");

            migrationBuilder.AddColumn<DateTime>(
                name: "LoginExpiry",
                table: "University_Register",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddForeignKey(
                name: "FK_Students_Subjects_Student_Results_StudentResultsId",
                table: "Students_Subjects",
                column: "StudentResultsId",
                principalTable: "Student_Results",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Students_Subjects_Student_Results_StudentResultsId",
                table: "Students_Subjects");

            migrationBuilder.DropColumn(
                name: "LoginExpiry",
                table: "University_Register");

            migrationBuilder.RenameColumn(
                name: "StudentResultsId",
                table: "Students_Subjects",
                newName: "ResultsId");

            migrationBuilder.RenameIndex(
                name: "IX_Students_Subjects_StudentResultsId",
                table: "Students_Subjects",
                newName: "IX_Students_Subjects_ResultsId");

            migrationBuilder.AddForeignKey(
                name: "FK_Students_Subjects_Student_Results_ResultsId",
                table: "Students_Subjects",
                column: "ResultsId",
                principalTable: "Student_Results",
                principalColumn: "Id");
        }
    }
}
